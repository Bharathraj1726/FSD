package DSA;

import java.util.Stack;
import java.util.LinkedList;
import java.util.Queue;

public class MyStack {
    static Queue queue1, queue2;

    // static void reversequeue() {
    // Stack stack = new Stack<>();
    // while (!queue.isEmpty()) {
    // stack.add(queue.peek());
    // queue.remove();
    // }
    // while (!stack.isEmpty()) {
    // queue.add(stack.peek());
    // stack.pop();
    // }
    // }
    static void push(int item) {

        queue1.add(item);

    }

    static int item;

    static int pop() {
        item = 0;
        while (!queue1.isEmpty()) {
            queue2.add(queue1.peek());
            queue1.remove();
            if (queue1.isEmpty()) {
                item = (int) queue2.peek();
                queue2.remove();
            }
        }

        while (!queue2.isEmpty()) {
            queue1.add(queue2.peek());
            queue2.remove();
        }
        return item;
    }

    // static int top() {

    // }

    // static boolean empty() {

    // }

    public static void main(String[] args) {
        queue1 = new LinkedList<>();
        queue2 = new LinkedList<>();
        MyStack myStack = new MyStack();
        myStack.push(1);
        myStack.push(2);
        myStack.push(6);
        myStack.push(2);
        // myStack.top(); // return 2
        MyStack.pop();

        MyStack.pop(); // return 2
        // myStack.empty(); // return False
        System.out.println(queue1.peek());
        // reversequeue();
        while (!queue1.isEmpty()) {
            System.out.print(queue1.peek() + " ");
            queue1.remove();
        }

    }
}
