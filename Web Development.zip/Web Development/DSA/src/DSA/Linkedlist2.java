package DSA;

class Node {
    int data;
    Node next;

    Node(int x) {
        data = x;
        next = null;
    }
}

public class Linkedlist2 {

    Node head;

    public void insertStart(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;

    }

    public void insertLast(int data) {
        Node newNode = new Node(data);

        if (head == null) {

            head = newNode;
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        temp.next = newNode;
    }

    public void insertPosition(int pos, int data) {
        Node newNode = new Node(data);
        int size = calcsize();
        System.out.println(size);
        if (pos < 1 || pos > size) {
            System.out.println("Can't Insert " + data + "at position " + pos);
            return;
        } else {
            Node temp = head;
            for (int i = 1; i < pos; i++) {
                temp = temp.next;
            }
            newNode.next = temp.next;
            temp.next = newNode;
        }
    }

    public void deleteAtpos(int pos) {
        Node node = head;
        int size = calcsize();
        if (pos < 0 || size < pos || head == null) {
            System.out.println("can't delete");
            return;
        } else if (pos == 0) {
            Node temp = head;
            head = temp.next;
        } else {
            Node prev = head;
            for (int i = 0; i < pos; i++) {
                prev = node;
                node = node.next;
            }
            prev.next = node.next;
        }

    }

    public void deleteVal(int val) {
        Node node = head;
        Node prev = null;
        int size = calcsize();
        if (node.next == null) {
            System.out.println(val + " Deleted");
            return;
        } else if (node != null && node.data == val) {
            Node temp = head;
            head = temp.next;
            System.out.println(head.data + " Value deleted");
            return;
        }
        while (node != null && node.data != val) {
            prev = node;
            node = node.next;

        }
        if (node == null) {
            System.out.println("Value not found");
            return;
        }

        prev.next = node.next;
        System.out.println("Value deleted ie " + val);

    }

    public int calcsize() {
        Node node = head;
        int size = 0;
        while (node != null) {
            node = node.next;
            size++;
        }
        return size;
    }

    public void display() {
        Node node = head;
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
        System.out.println(" ");
    }

    public static void main(String args[]) {

        Linkedlist2 ll = new Linkedlist2();

        ll.insertStart(12);
        ll.insertStart(16);
        ll.insertStart(20);
        ll.insertLast(10);
        ll.insertLast(14);
        ll.insertLast(18);
        ll.insertLast(11);

        // Inserts after 3rd position
        ll.insertPosition(5, 25);
        ll.display();

        ll.deleteAtpos(0);
        ll.display();
        ll.deleteVal(16);
        ll.display();
    }
}
