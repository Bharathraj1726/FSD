package DSA;

class Node {
    int data;
    Node prev, next;

    Node(int x) {
        data = x;
        next = null;
        prev = null;
    }
}

class DoublyList {
    Node head;

    public void insertStart(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        if (head != null) {
            head.prev = newNode;
        }
        head = newNode;

    }

    public void insertLast(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = newNode;
        newNode.prev = temp;

    }

    public int calcsize() {
        Node node = head;
        int size = 0;
        while (node != null) {
            node = node.next;
            size++;
        }
        return size;
    }

    public void insertPosition(int pos, int data) {
        Node newNode = new Node(data);
        int size = calcsize();
        System.out.println(size);
        if (pos < 1 || pos > size) {
            System.out.println("Can't Insert " + data + "at position " + pos);
            return;
        } else {
            Node temp = head;
            for (int i = 1; i < pos; i++) {
                temp = temp.next;
            }
            newNode.next = temp.next;
            temp.next = newNode;
        }
    }

    public void deleteVal(int data) {
        Node temp = head;
        Node prev = null;
        if (temp.next == null && temp.data != data) {
            System.out.println("Value not found");
            return;
        } else if (temp.data == data) {
            Node temp1 = head;
            head = temp1.next;
            System.out.println(temp1.data + "deleted");
            return;
        }
        while (temp.data != data && temp.next != null) {
            prev = temp;
            temp = temp.next;
        }
        if (temp.next == null) {
            System.out.println("Value not found");
            return;
        }
        prev.next = temp.next;
        System.out.println(data + " Value found");
    }

    public void display() {
        Node node = head;
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
        System.out.println(" ");
    }

    public static void main(String args[]) {

        DoublyList ll = new DoublyList();

        ll.insertStart(12);
        ll.deleteVal(12);
        ll.display();
        ll.insertStart(16);
        ll.insertStart(20);
        ll.insertLast(10);
        ll.insertLast(14);
        ll.insertLast(18);
        ll.insertLast(11);

        // // Inserts after 3rd position
        ll.insertPosition(6, 25);
        ll.display();

        // ll.deleteAtpos(0);
        // ll.display();
        ll.deleteVal(16);
        ll.display();
    }
}