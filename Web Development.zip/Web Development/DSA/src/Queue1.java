public class Queue1 {

    int capacity;
    int front, rear;
    int[] array;

    Queue1(int cap) {
        capacity = cap;
        front = -1;
        rear = -1;
        array = new int[capacity];
    }

    boolean isFull() {
        return front == 0 && rear == capacity - 1;
    }

    boolean isEmpty() {
        return front == -1;

    }

    void enqueue(int item) {
        if (isFull()) {
            return;
        } else {
            if (front == -1)
                front = 0;
            rear++;
            array[rear] = item;
            System.out.println(item + " enqueued to queue");
        }

    }

    int dequeue() {
        if (isEmpty())
            return Integer.MIN_VALUE;

        int item = array[front];
        front++;
        if (front > rear) {
            front = rear = -1;
        }
        System.out.println(item + " dequeued from queue");
        return item;
    }

    int front() {
        if (isEmpty())
            return Integer.MIN_VALUE;

        return array[front];
    }

    int rear() {
        if (isEmpty()) {
            return Integer.MIN_VALUE;
        }
        return array[rear];
    }

    void reverse() {
        int size = array.length - 1;
        int temp = 0;
        for (int i = 0; i <= size; i++) {
            temp = array[i];
            array[i] = array[size];
            array[size] = temp;
            size--;
        }
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i] + " ");
        }
    }
}

class Temp {
    public static void main(String[] args) {
        Queue1 queue = new Queue1(10);

        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);
        queue.enqueue(6);
        queue.enqueue(7);
        queue.enqueue(8);
        queue.enqueue(9);
        queue.enqueue(10);

        queue.reverse();

        System.out.println("Front: " + queue.front());
        System.out.println("Rear: " + queue.rear());
    }
}