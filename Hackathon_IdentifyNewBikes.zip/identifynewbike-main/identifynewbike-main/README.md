# identifynewbike

Problem Statement : Identify New Bikes

Display upcoming bikes details like , bike name, its price and expected launch date in India
1. Manufacturer should be Honda.
2. Bike price should be less than 4Lac
(Suggested site: zigwheels however you are free to use any legitimate site)
Detailed Description: Hackath Ideas

1. Display "Upcoming" bikes details like bike name, price and expected launch date in India, for manufacturer 'Honda' & Bike price should be less than 4Lac.
2. For Used cars in Chennai, extract all the popular models in a List; Display the same
3. Try to 'Login' with google, give invalid account details & capture the error message
(Suggested site: zigwheels.com however you are free to use any legitimate site)
